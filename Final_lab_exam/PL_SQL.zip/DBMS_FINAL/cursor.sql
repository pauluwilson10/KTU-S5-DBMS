CREATE TABLE honors (
    roll_no NUMBER PRIMARY KEY NOT NULL,
    name VARCHAR2(20),
    s1 NUMBER,
    s2 NUMBER
);

INSERT INTO honors VALUES (52, 'Bob', 8, 8); 
INSERT INTO honors VALUES (53, 'Charlie', 9, 4); 
INSERT INTO honors VALUES (51, 'Alice', 5, 2); 
INSERT INTO honors VALUES (54, 'David', 65, 70); 
INSERT INTO honors VALUES (55, 'Eve', 80, 85); 
INSERT INTO honors VALUES (56, 'Frank', 55, 60);

SET SERVEROUTPUT ON;

DECLARE
    CURSOR student_honors IS
        SELECT roll_no, name, s1, s2 FROM honors WHERE (s1 + s2) > 12 ORDER BY roll_no;
    max_mark NUMBER(10) := 0;--max_mark honors.s1%type;
BEGIN
    FOR student IN student_honors LOOP
        DBMS_OUTPUT.PUT_LINE('Roll Number: ' || student.roll_no || 
                             ', Name: ' || student.name || 
                             ', Semester 1: ' || student.s1 || 
                             ', Semester 2: ' || student.s2);
        
        IF student.s1 > max_mark THEN
            max_mark := student.s1;
        END IF;
    END LOOP;

    DBMS_OUTPUT.PUT_LINE('Maximum mark in Semester 1: ' || max_mark);
END;
/

DROP TABLE honors;
