CREATE TABLE bill(
    cust_id NUMBER PRIMARY KEY NOT NULL,
    name VARCHAR2(20),
    past NUMBER,
    present NUMBER
);

INSERT INTO bill VALUES (101, 'Jacob', 146, 350); 
INSERT INTO bill VALUES (102, 'Henry', 565, 200); 
INSERT INTO bill VALUES (103, 'John', 145, 650); 
INSERT INTO bill VALUES (104, 'Evan', 77, 160); 
INSERT INTO bill VALUES (105, 'Eric', 57, 380); 
INSERT INTO bill VALUES (106, 'Jim', 132, 100); 
INSERT INTO bill VALUES (107, 'Susan', 801, 99); 

ACCEPT acco PROMPT 'Enter Account number';

DECLARE
    CURSOR cust_info(acc_number IN NUMBER) IS
        SELECT cust_id, name, past, present FROM bill WHERE cust_id = acc_number;
    reading NUMBER(20);
    no NUMBER(20) := &acco;
    charge NUMBER(10, 6);
BEGIN
    FOR customer IN cust_info(no) LOOP
        reading := customer.present - customer.past;

        IF reading BETWEEN 1 AND 100 THEN 
            charge := reading * 5;
        ELSIF reading BETWEEN 101 AND 300 THEN
            charge := (100 * 5) + (reading - 100) * 7.5;
        ELSIF reading BETWEEN 301 AND 500 THEN
            charge := (100 * 5) + (200 * 7.5) + (reading - 300) * 15;
        ELSE
            charge := (100 * 5) + (200 * 7.5) + (200 * 15) + (reading - 500) * 22.5;
        END IF;

        DBMS_OUTPUT.PUT_LINE('Consumer No: ' || customer.cust_id); 
        DBMS_OUTPUT.PUT_LINE('Name: ' || customer.name);
        DBMS_OUTPUT.PUT_LINE('Units Consumed: ' || reading); 
        DBMS_OUTPUT.PUT_LINE('Total Charge: ' || charge); 
    END LOOP;

    IF SQL%NOTFOUND THEN
        DBMS_OUTPUT.PUT_LINE('Invalid customer');
    END IF;
END;
/
DROP TABLE bill;
