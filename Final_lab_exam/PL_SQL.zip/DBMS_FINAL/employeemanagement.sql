SET SERVEROUTPUT ON;

ACCEPT id NUMBER PROMPT 'Enter Employee ID to get salary: ';
ACCEPT dele NUMBER PROMPT 'Enter Employee ID to delete: ';

-- Create Employee Table
CREATE TABLE employee (
    Eid NUMBER PRIMARY KEY,
    Ename VARCHAR2(50),
    Eaddress VARCHAR2(100),
    Esalary NUMBER(10, 2)
);

-- Package Specification
CREATE OR REPLACE PACKAGE employee_package AS
    PROCEDURE add_employee(p_eid IN NUMBER, p_name IN VARCHAR2, p_address IN VARCHAR2, p_salary IN NUMBER);
    PROCEDURE delete_employee(p_eid IN NUMBER);
    PROCEDURE listemployee;
    FUNCTION get_salary(p_eid IN NUMBER) RETURN NUMBER;
END employee_package;

-- Package Body
CREATE OR REPLACE PACKAGE BODY employee_package AS
    PROCEDURE add_employee(p_eid IN NUMBER, p_name IN VARCHAR2, p_address IN VARCHAR2, p_salary IN NUMBER) AS
    BEGIN
        INSERT INTO employee VALUES (p_eid, p_name, p_address, p_salary);
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Employee: ' || p_name || ' added successfully');
    END add_employee;

    PROCEDURE delete_employee(p_eid IN NUMBER) AS
    BEGIN
        DELETE FROM employee WHERE Eid = p_eid;
        IF SQL%ROWCOUNT = 0 THEN
            DBMS_OUTPUT.PUT_LINE('No employee found with ID ' || p_eid);
        ELSE
            DBMS_OUTPUT.PUT_LINE('Employee successfully deleted');
        END IF;
        COMMIT;
    END delete_employee;

    PROCEDURE listemployee AS
    BEGIN
        FOR emp IN (SELECT * FROM employee) LOOP
            DBMS_OUTPUT.PUT_LINE('ID: ' || emp.Eid || ', Name: ' || emp.Ename || ', Address: ' || emp.Eaddress || ', Salary: ' || emp.Esalary);
        END LOOP;
    END listemployee;

    FUNCTION get_salary(p_eid IN NUMBER) RETURN NUMBER AS
        sal NUMBER(10, 2);
    BEGIN
        SELECT Esalary INTO sal FROM employee WHERE Eid = p_eid;
        RETURN sal;
    EXCEPTION 
        WHEN no_data_found THEN
            DBMS_OUTPUT.PUT_LINE('Employee with ID ' || p_eid || ' not found.');
            RETURN NULL;
    END get_salary;
END employee_package;

-- Anonymous Block for Testing
DECLARE
    pro_salary NUMBER(10, 2);
    id NUMBER := &id;
    dele NUMBER := &dele;
BEGIN
    -- Adding sample employees
    employee_package.add_employee(1, 'Alice Johnson', '101 Maple St', 55000); 
    employee_package.add_employee(2, 'Bob Smith', '202 Oak St', 60000);
    employee_package.add_employee(3, 'Charlie Brown', '303 Pine St', 50000); 

    -- Retrieve and display salary of a specific employee
    pro_salary := employee_package.get_salary(id);
    IF pro_salary IS NOT NULL THEN 
        DBMS_OUTPUT.PUT_LINE('Salary of employee with ID ' || id || ' is ' || pro_salary);
    END IF;

    -- List all employees
    employee_package.listemployee;

    -- Delete specified employee and list all employees again
    employee_package.delete_employee(dele);
    employee_package.listemployee;
END;
/
