create table employee(
    ename varchar2(20),
    designation varchar2(20),
    salary number
);

create table errorinsal(
    ename varchar2(20),
    designation varchar2(20),
    salary number
);
INSERT INTO employee (ename, designation, salary) VALUES ('Alice', 'des1', 12000);
INSERT INTO employee (ename, designation, salary) VALUES ('Bob', 'des2', 8000);
INSERT INTO employee (ename, designation, salary) VALUES ('Charlie', 'des3', 3000);
INSERT INTO employee (ename, designation, salary) VALUES ('David', 'des1', 9000); 

CREATE OR REPLACE PROCEDURE check_salary_errors AS
BEGIN
    FOR emp IN (SELECT ename, designation, salary FROM employee) LOOP
        IF (emp.designation = 'des1' AND emp.salary <= 10000) OR
           (emp.designation = 'des2' AND emp.salary <= 7000) OR
           (emp.designation = 'des3' AND emp.salary <= 2000) THEN
            -- Insert records that do not meet the condition into ErrorInSal
            INSERT INTO ErrorInSal (ename, designation, salary)
            VALUES (emp.ename, emp.designation, emp.salary);
        END IF;
    END LOOP;
    
    COMMIT;
END check_salary_errors;
/

set SERVEROUTPUT on;
BEGIN
check_salary_errors;
end;
/
