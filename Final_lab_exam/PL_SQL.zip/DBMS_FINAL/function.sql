-- Create the table and insert values
CREATE TABLE balance (
    cid NUMBER PRIMARY KEY NOT NULL,
    bal NUMBER
);

INSERT INTO balance VALUES (101, 10500); 
INSERT INTO balance VALUES (102, 7830); 
INSERT INTO balance VALUES (103, 45000); 
INSERT INTO balance VALUES (104, 70000); 
INSERT INTO balance VALUES (105, 500); 

-- Create the function to categorize based on balance
CREATE OR REPLACE FUNCTION category(bal IN NUMBER)
RETURN VARCHAR2 AS
    cat VARCHAR2(20);
BEGIN
    IF bal > 50000 THEN
        cat := 'Platinum';
    ELSIF bal > 10000 THEN
        cat := 'Gold';
    ELSE
        cat := 'Silver';
    END IF;
    RETURN cat;
END;
/

-- PL/SQL block to display the customer details along with category
BEGIN
    FOR customer IN (SELECT cid, bal FROM balance) LOOP
        DBMS_OUTPUT.PUT_LINE('CID: ' || customer.cid || ' | Balance: ' || customer.bal || ' | Category: ' || category(customer.bal));
    END LOOP;
END;
/

-- Drop the table after use
DROP TABLE balance;
