CREATE TABLE custo(
    customername VARCHAR2(50),
    customerid NUMBER PRIMARY KEY NOT NULL,
    address VARCHAR2(50),
    phonenumber VARCHAR2(15),
    pancardnumber VARCHAR2(20)
);

CREATE TABLE loan (
    loanid NUMBER PRIMARY KEY NOT NULL,
    loandate DATE,
    amountpaid NUMBER,
    custid NUMBER,
    FOREIGN KEY (custid) REFERENCES custo(customerid)
);
-- Insert sample data into the customer table
INSERT INTO custo (customername, customerid, address, phonenumber, pancardnumber)
VALUES ('John Doe', 1, '123 Elm Street', '1234567890', 'ABCDE1234F');

INSERT INTO custo (customername, customerid, address, phonenumber, pancardnumber)
VALUES ('Jane Smith', 2, '456 Oak Avenue', '0987654321', 'FGHIJ5678K');

INSERT INTO custo (customername, customerid, address, phonenumber, pancardnumber)
VALUES ('Alice Johnson', 3, '789 Maple Road', '1122334455', 'KLMNO9012P');

-- Insert sample data into the loan table
INSERT INTO loan (loanid, loandate, amountpaid, custid)
VALUES (101, TO_DATE('01-01-2023', 'DD-MM-YYYY'), 5000, 1);

INSERT INTO loan (loanid, loandate, amountpaid, custid)
VALUES (102, TO_DATE('15-02-2023', 'DD-MM-YYYY'), 3000, 1);

INSERT INTO loan (loanid, loandate, amountpaid, custid)
VALUES (103, TO_DATE('20-03-2023', 'DD-MM-YYYY'), 7000, 2);

INSERT INTO loan (loanid, loandate, amountpaid, custid)
VALUES (104, TO_DATE('10-04-2023', 'DD-MM-YYYY'), 6000, 3);

INSERT INTO loan (loanid, loandate, amountpaid, custid)
VALUES (105, TO_DATE('25-05-2023', 'DD-MM-YYYY'), 8000, 2);

CREATE OR REPLACE PROCEDURE loan_detail(cus IN NUMBER, ld IN DATE) AS
    CURSOR customer_detail IS
        SELECT loanid, loandate, amountpaid 
        FROM loan 
        WHERE custid = cus AND loandate > ld;
    record_found BOOLEAN := FALSE;
BEGIN
    FOR customer IN customer_detail LOOP
        DBMS_OUTPUT.PUT_LINE('Loan ID: ' || customer.loanid || 
                             ', Loan Date: ' || customer.loandate || 
                             ', Amount Paid: ' || customer.amountpaid);
        record_found := TRUE;
    END LOOP;
    
    IF NOT record_found THEN
        DBMS_OUTPUT.PUT_LINE('No record found');
    END IF;
END loan_detail;
/
set SERVEROUTPUT on;

DECLARE
    customer_id NUMBER := &customer_id;
    input_date DATE := TO_DATE('&input_date', 'DD-MM-YYYY');
BEGIN
    loan_detail(customer_id, input_date);
END;
/
