CREATE OR REPLACE TRIGGER stock_update_trigger
BEFORE INSERT OR UPDATE ON STOCK
FOR EACH ROW
DECLARE
    under_zero EXCEPTION;
    spn VARCHAR2(100);
    qty NUMBER;
BEGIN
    -- Raise an exception if QTYINSTOCK is negative
    IF :NEW.QTYINSTOCK < 0 THEN
        RAISE under_zero;
    END IF;

    -- Log the operation (receipt or issue) in AUDITSTOCK
    IF :NEW.QTYINSTOCK > :OLD.QTYINSTOCK THEN
        INSERT INTO AUDITSTOCK (ITEMNO, OPERATION, ODATE)
        VALUES (:NEW.ITEMNO, 'receipt', SYSDATE);
    ELSIF :NEW.QTYINSTOCK < :OLD.QTYINSTOCK THEN
        INSERT INTO AUDITSTOCK (ITEMNO, OPERATION, ODATE)
        VALUES (:NEW.ITEMNO, 'issue', SYSDATE);
    END IF;

    -- If stock goes below reorder level, place an order
    IF :NEW.QTYINSTOCK < :NEW.REORDER THEN
        SELECT SUPNAME INTO spn FROM IDESC WHERE ITEMNO = :NEW.ITEMNO;
        qty := :NEW.MAXLEVEL - :NEW.QTYINSTOCK;
        INSERT INTO ORDERS (ITEMNO, SUPNAME, QUANTITY)
        VALUES (:NEW.ITEMNO, spn, qty);
    END IF;

EXCEPTION
    WHEN under_zero THEN
        DBMS_OUTPUT.PUT_LINE('Error: Stock cannot be below zero');
END;
