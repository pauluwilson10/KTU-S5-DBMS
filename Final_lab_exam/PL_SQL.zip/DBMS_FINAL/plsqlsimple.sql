CREATE TABLE bank (
    acc_num VARCHAR2(20) PRIMARY KEY NOT NULL,
    bal NUMBER(10)
);

INSERT INTO bank VALUES('C0001', 5000);
INSERT INTO bank VALUES('C0002', 10000);

SET SERVEROUTPUT ON;

ACCEPT account PROMPT 'Enter Account number: ';
ACCEPT choice PROMPT 'Enter Choice 1: Debit  2: Credit: ';
ACCEPT amount PROMPT 'Enter Amount: ';

DECLARE
    balance NUMBER(20);
    choice NUMBER := &choice;
    amount NUMBER := &amount;
    account VARCHAR2(20) := '&account';
BEGIN
    IF choice = 2 THEN  -- Credit
        UPDATE bank SET bal = bal + amount WHERE acc_num = account;
        DBMS_OUTPUT.PUT_LINE('Credited amount: ' || amount);
    ELSIF choice = 1 THEN  -- Debit
        UPDATE bank SET bal = bal - amount WHERE acc_num = account;
        DBMS_OUTPUT.PUT_LINE('Debited amount: ' || amount);
    ELSE
        DBMS_OUTPUT.PUT_LINE('Invalid Selection');
    END IF;

    -- Display the updated balance
    SELECT bal INTO balance FROM bank WHERE acc_num = account;
    DBMS_OUTPUT.PUT_LINE('Balance Amount: ' || balance);

    -- Warning for low balance
    IF balance < 500 THEN
        DBMS_OUTPUT.PUT_LINE('Warning: Critical Amount');
    END IF;
END;
/
