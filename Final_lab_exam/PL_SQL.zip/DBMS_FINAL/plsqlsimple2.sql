create table average(
    id VARCHAR(10) primary key not null,
    name varchar(10),
    mark number(10) not null
);
insert into average values('S01','TOM',55); 
insert into average values('S02','ANN',70); 
insert into average values('S03','DIA',35); 

DECLARE
    avr NUMBER(10,5);
    cdate varchar(20);
BEGIN
    SELECT AVG(MARK) INTO avr from average;
    if avr<40 THEN
        dbms_output.put_line('Need Improvment');
    ELSE
        dbms_output.put_line('good average marks');
    end if;
    dbms_output.put_line('Date:'|| SYSDATE);
    cdate:=to_char(SYSDATE,'DAY');
    dbms_output.put_line('Day:'|| cdate);
end;
/
drop table average;


