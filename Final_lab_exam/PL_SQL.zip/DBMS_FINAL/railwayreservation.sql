-- Create the railway table
CREATE TABLE railway (
    tno NUMBER PRIMARY KEY NOT NULL,
    tname VARCHAR2(20),
    tdate DATE,
    destination VARCHAR2(20),
    seats NUMBER
);

-- Create a sequence for train numbers
CREATE SEQUENCE train_update
START WITH 1
INCREMENT BY 1;

-- Insert train data using the sequence
INSERT INTO railway VALUES (train_update.NEXTVAL, 'Express1', TO_DATE('15-OCT-2024', 'DD-MON-YYYY'), 'City A', 200);
INSERT INTO railway VALUES (train_update.NEXTVAL, 'Express2', TO_DATE('01-NOV-2024', 'DD-MON-YYYY'), 'City B', 150);
INSERT INTO railway VALUES (train_update.NEXTVAL, 'Express3', TO_DATE('05-DEC-2024', 'DD-MON-YYYY'), 'Mountain Town', 120);
INSERT INTO railway VALUES (train_update.NEXTVAL, 'Express4', TO_DATE('20-OCT-2024', 'DD-MON-YYYY'), 'Coastal City', 180);
INSERT INTO railway VALUES (train_update.NEXTVAL, 'Express5', TO_DATE('15-NOV-2024', 'DD-MON-YYYY'), 'City C', 250);
INSERT INTO railway VALUES (train_update.NEXTVAL, 'Express6', TO_DATE('10-JAN-2025', 'DD-MON-YYYY'), 'City D', 300);
INSERT INTO railway VALUES (train_update.NEXTVAL, 'Express7', TO_DATE('25-FEB-2025', 'DD-MON-YYYY'), 'City E', 220);

-- Reservation procedure
CREATE OR REPLACE PROCEDURE reserve(train_no IN NUMBER, seat IN NUMBER) AS
    available NUMBER(20);
BEGIN
    SELECT seats INTO available FROM railway WHERE tno = train_no;

    IF seat <= available THEN
        UPDATE railway SET seats = seats - seat WHERE tno = train_no;
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Reservation made for ' || seat || ' seats');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Not enough seats available');
    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Invalid train number');
END reserve;

-- Cancellation procedure
CREATE OR REPLACE PROCEDURE cancel(train_no IN NUMBER, seat IN NUMBER) AS
BEGIN
    UPDATE railway SET seats = seats + seat WHERE tno = train_no;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Cancellation successful for ' || seat || ' seats.');
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Invalid train number');
END cancel;

-- Main loop for SQL*Plus
DECLARE
    train_no NUMBER;
    seats_requested NUMBER;
    choice NUMBER;
BEGIN
    LOOP
        -- Prompt for choice and store it in the variable
        choice := &choice;

        -- Exit the loop if the user enters 0
        EXIT WHEN choice = 0;

        -- Prompt for train number and seats only if choice is 1 or 2
        IF choice = 1 OR choice = 2 THEN
            train_no := &train_no;
            seats_requested := &seats_requested;
        END IF;

        -- Execute the appropriate procedure based on choice
        IF choice = 1 THEN
            reserve(train_no, seats_requested);
        ELSIF choice = 2 THEN
            cancel(train_no, seats_requested);
        ELSE
            DBMS_OUTPUT.PUT_LINE('Invalid choice');
        END IF;
    END LOOP;

    DBMS_OUTPUT.PUT_LINE('Exiting program.');
END;
/
