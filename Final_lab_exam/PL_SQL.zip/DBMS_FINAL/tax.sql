-- Creating the employee table
CREATE TABLE employee (
    id NUMBER PRIMARY KEY NOT NULL,
    name VARCHAR2(20),
    salary NUMBER(20,5)
);

-- Creating the tax table
CREATE TABLE tax (
    emp_id NUMBER,
    tax_amount NUMBER(10,6),
    FOREIGN KEY (emp_id) REFERENCES employee(id)
);

CREATE or replace trigger tax_cal
after insert on employee
for each ROW
DECLARE
    tax_amount number(20,5);
BEGIN
    if :new.salary<=5000 THEN
        tax_amount:=:new.salary*0.1;
    ELSIF :new.salary BETWEEN 5001 and 10000 THEN
        tax_amount:=:new.salary*0.2;
    ELSIF :new.salary BETWEEN 10001 and 15000 THEN
        tax_amount:=:new.salary*0.3;
    ELSE
        tax_amount:=0;
    end if;
    insert into tax VALUES(:new.id,tax_amount);
end;
/
        

