SET SERVEROUTPUT ON
ACCEPT amount PROMPT 'Enter the present reading: '

DECLARE
    v_consumer_no NUMBER(10);
    v_past_reading NUMBER(10);
    v_present_reading NUMBER(10);
    v_units_consumed NUMBER(10);
    v_charge NUMBER(10);
    v_amount_number NUMBER := &amount;
    
    CURSOR elec_cursor(p_consumer_no NUMBER) IS
        SELECT present_reading, past_reading
        FROM electricity
        WHERE consumer_no = p_consumer_no;
BEGIN
    dbms_output.put_line('Enter the consumer number:');
    v_consumer_no := &consumer_no;
    
    OPEN elec_cursor(v_consumer_no);
    FETCH elec_cursor INTO v_present_reading, v_past_reading;
    
    IF elec_cursor%FOUND THEN
        -- Calculate units consumed
        v_units_consumed := v_amount_number - v_past_reading;
        
        -- Update the past_reading with the present reading
        UPDATE electricity 
        SET past_reading = v_present_reading 
        WHERE consumer_no = v_consumer_no;
        
        -- Calculate the charge based on the units consumed
        IF v_units_consumed <= 100 THEN
            v_charge := v_units_consumed * 5;
        ELSIF v_units_consumed BETWEEN 101 AND 300 THEN
            v_charge := (100 * 5) + (v_units_consumed - 100) * 7.5;
        ELSIF v_units_consumed BETWEEN 301 AND 500 THEN
            v_charge := (100 * 5) + (200 * 7.5) + (v_units_consumed - 300) * 15;
        ELSE
            v_charge := (100 * 5) + (200 * 7.5) + (200 * 15) + (v_units_consumed - 500) * 22.5;
        END IF;
        
        -- Display the results
        DBMS_OUTPUT.PUT_LINE('Consumer no: ' || v_consumer_no);
        DBMS_OUTPUT.PUT_LINE('Units Consumed: ' || v_units_consumed);
        DBMS_OUTPUT.PUT_LINE('Charge: ' || v_charge);
    ELSE
        DBMS_OUTPUT.PUT_LINE('No data found for Consumer No: ' || v_consumer_no);
    END IF;
    
    CLOSE elec_cursor;
END;
/



--Create an employee table(ename, designation, salary)

Create a procedure that checks whether : designation=des1 and salaray>10000 
Or designation=des2 and salary>7000 
or designation=des3 and salary>2000

Add only those values to a new table ErrorInSal(ename, designation, salary)