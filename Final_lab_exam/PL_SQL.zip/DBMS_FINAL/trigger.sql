CREATE TABLE honors (
    roll_no NUMBER PRIMARY KEY NOT NULL,
    name VARCHAR2(20),
    s1 NUMBER,
    s2 NUMBER
);

INSERT INTO honors VALUES (52, 'Bob', 8, 8); 
INSERT INTO honors VALUES (53, 'Charlie', 9, 4); 
INSERT INTO honors VALUES (51, 'Alice', 5, 2); 
INSERT INTO honors VALUES (54, 'David', 65, 70); 
INSERT INTO honors VALUES (55, 'Eve', 80, 85); 
INSERT INTO honors VALUES (56, 'Frank', 55, 60);

CREATE OR REPLACE TRIGGER honor
BEFORE INSERT OR DELETE OR UPDATE ON honors
FOR EACH ROW
DECLARE
    message VARCHAR2(100);
BEGIN
    IF DELETING THEN
        message := 'deleted ' || :old.name;
    ELSIF INSERTING THEN
        message := 'inserting ' || :new.name;
    ELSIF UPDATING THEN
        IF :new.name = :old.name THEN
            message := 'Updating: ' || :new.name;
        ELSE
            message := 'Updating: ' || :old.name || ' to ' || :new.name;
        END IF;
    END IF;
    DBMS_OUTPUT.PUT_LINE(message);
END;
