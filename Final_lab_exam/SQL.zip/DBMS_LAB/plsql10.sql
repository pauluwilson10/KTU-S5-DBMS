CREATE TABLE Employees (
    Eid INT PRIMARY KEY,               
    Ename VARCHAR(50),
    Eaddress VARCHAR(100),
    Esalary DECIMAL(10, 2)
);
create or replace package employee_managment AS
PROCEDURE add_employee(p_eid in int,p_ename in VARCHAR2(20),p_eaddress in VARCHAR2920,p_esalary in number(10,5));
PROCEDURE delete_employee(p_eid in int);
PROCEDURE list_employee;
FUNCTION get_salary (p_eid in int) return DECIMAL;
end employee_managment;
/
create or replace package body employee_managment as

create or replace procedure add_employee(p_eid in int,p_ename in VARCHAR2(20),p_eaddress in VARCHAR2920,p_esalary in number(10,5)) AS
begin   
insert into Employees VALUES (p_Eid, p_Ename, p_Eaddress, p_Esalary);
commit;
DBMS_OUTPUT.PUT_LINE('Employee ' || p_Ename || ' added successfully with ID ' || p_Eid || '.');
end add_employee;

create or replace procedure delete_employee(p_eid in int) as
begin 
delete from employee where eid=p_eid;
commit;
 DBMS_OUTPUT.PUT_LINE('Employee with ID ' || p_Eid || ' deleted successfully.');
end delete_employee;

create or replace procedure list_employee AS
CURSOR emp IS
select eid,ename,Esalary,Eaddress from employee;
BEGIN
FOR empvalue in emp loop
DBMS_OUTPUT.PUT_LINE('ID: ' || v_emp.Eid || ', Name: ' || v_emp.Ename || 
                             ', Address: ' || v_emp.Eaddress || ', Salary: ' || v_emp.Esalary);
end LOOP;
end list_employee;

function get_salary (p_eid in int)
return DECIMAL AS
     v_salary DECIMAL(10, 2);
    BEGIN
        SELECT Esalary INTO v_salary FROM Employees WHERE Eid = p_Eid;
        RETURN v_salary;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('Employee with ID ' || p_Eid || ' not found.');
            RETURN NULL;
    END Get_Salary;
    end employee_managment;
    /
    SET SERVEROUTPUT ON;

DECLARE
    v_salary DECIMAL(10, 2);
    v_emp_id_for_salary INT := &employee_id_for_salary;  -- Prompt for EmployeesID to get salary
    v_emp_id_for_deletion INT := &employee_id_for_deletion;  -- Prompt for EmployeesID to delete
BEGIN
    -- Add employees
    Employee_Package.Add_Employee(1, 'Alice Johnson', '101 Maple St', 55000);
    Employee_Package.Add_Employee(2, 'Bob Smith', '202 Oak St', 60000);
    Employee_Package.Add_Employee(3, 'Charlie Brown', '303 Pine St', 50000);
    
    -- List all employees
    Employee_Package.List_Employees;
    
    -- Get salary of an employee
    v_salary := Employee_Package.Get_Salary(v_emp_id_for_salary);  -- Get salary for user-specified EmployeeID
    IF v_salary IS NOT NULL THEN
        DBMS_OUTPUT.PUT_LINE('Salary of EmployeesID ' || v_emp_id_for_salary || ': ' || v_salary);
    END IF;
    
    -- Delete an employee
    Employee_Package.Delete_Employee(v_emp_id_for_deletion);  -- Delete employee with user-specified ID
    
    -- List employees again
    Employee_Package.List_Employees;
END;
/
