CREATE TABLE PRODUCT (product_no VARCHAR(15) NOT NULL,description VARCHAR(20) NOT NULL,company VARCHAR(15) NOT NULL,price INT NOT NULL,PRIMARY KEY (product_no));
CREATE TABLE CUSTOMER (cust_no VARCHAR(15) NOT NULL,name VARCHAR(20) NOT NULL,age INT NOT NULL,city VARCHAR(30) NOT NULL,pincode INT NOT NULL,state VARCHAR(15) NOT NULL,PRIMARY KEY (cust_no));
CREATE TABLE SUPPLIER (s_no VARCHAR(10) NOT NULL,sname VARCHAR(20) NOT NULL,age INT NOT NULL,city VARCHAR(15) NOT NULL,PRIMARY KEY (s_no));
CREATE TABLE PURCHASE (order_no VARCHAR(15) NOT NULL,custno VARCHAR(15) NOT NULL,prono VARCHAR(15) NOT NULL,quantity INT NOT NULL,orderdate DATE,PRIMARY KEY (order_no),FOREIGN KEY (custno) REFERENCES CUSTOMER(cust_no),FOREIGN KEY (prono) REFERENCES PRODUCT(product_no));

INSERT INTO PRODUCT VALUES ('P00001', '12 W Flood Light', 'Wipro', 5000);
INSERT INTO PRODUCT VALUES('P00002', 'Laptop Adapter', 'Dell', 1560);
INSERT INTO PRODUCT VALUES('P00003', 'Tablet', 'HCL', 11000);
INSERT INTO PRODUCT VALUES('P00004', 'Garnet 50W led', 'Wipro', 999);
INSERT INTO PRODUCT VALUES('P00005', 'Laptop Charger', 'HCL', 1690);

INSERT INTO CUSTOMER VALUES ('C00001', 'Ivan Bayross', 35, 'Bombay', 400054, 'Maharashtra');
INSERT INTO CUSTOMER VALUES('C00002', 'Vandana Saitwal', 35, 'Madras', 780001, 'Tamilnadu');
INSERT INTO CUSTOMER VALUES('C00003', 'Pramada Jaguste', 55, 'Bombay', 400057, 'Maharashtra');
INSERT INTO CUSTOMER VALUES('C00004', 'Basu Navindgi', 45, 'Bombay', 400056, 'Maharashtra');
INSERT INTO CUSTOMER VALUES('C00005', 'Ravi Sreedharan', 25, 'Delhi', 100001, 'Delhi');
INSERT INTO CUSTOMER VALUES('C00006', 'Rukmini', 25, 'Madras', 780001, 'Tamilnadu');

INSERT INTO SUPPLIER VALUES ('S001', 'Ivan Bayross', 35, 'Bombay');
INSERT INTO SUPPLIER VALUES('S002', 'Nirmala Agarwal', 35, 'Madras');
INSERT INTO SUPPLIER VALUES('C003', 'Susmitha', 55, 'Bombay');
INSERT INTO SUPPLIER VALUES('C004', 'Basu Navindgi', 45, 'Bombay');    
INSERT INTO SUPPLIER VALUES('C005', 'Ravi Sreedharan', 25,'Delhi');
INSERT INTO SUPPLIER VALUES('C006', 'Nanda Gopal', 25, 'Madras'); 

INSERT INTO PURCHASE VALUES ('O00001', 'C00002', 'P00003', 2, '20-JAN-16');
INSERT INTO PURCHASE VALUES('O00002', 'C00003', 'P00002', 1, '27-JAN-16');
INSERT INTO PURCHASE VALUES('O00003', 'C00004', 'P00002', 3, '28-JAN-16');
INSERT INTO PURCHASE VALUES('O00004', 'C00006', 'P00001', 3, '20-FEB-16');
INSERT INTO PURCHASE VALUES('O00005', 'C00003', 'P00005', 4, '07-APR-16');
INSERT INTO PURCHASE VALUES('O00006', 'C00004', 'P00002', 2, '22-MAY-16');
INSERT INTO PURCHASE VALUES('O00007', 'C00005', 'P00004', 1, '26-MAY-16');

-- List customer- numbers of all who purchased the product 'Laptop Adapter' during January
select p.custno from purchase p inner join product pro on p.prono=pro.product_no where DESCRIPTION='Laptop Adapter'and orderdate LIKE '%JAN%';

--Get customer names  of all who purchased P00002 
select DISTINCT(c.name) from customer c inner join purchase p on c.cust_no=p.custno where p.prono='P00002';

--List customer numbers of all who have purchased products with a cost more than Rs.1600.
SELECT P.custno FROM PURCHASE P INNER JOIN PRODUCT PRO ON P.PRONO=PRO.product_no WHERE PRO.price>1600; 

--List customer names of all who have purchased products with a cost more than Rs .1500 during January.
SELECT C.Name FROM CUSTOMER C INNER JOIN PURCHASE P ON C.cust_no=P.custno INNER JOIN PRODUCT PRO ON P.PRONO=PRO.product_no WHERE PRO.price>1500 AND P.orderdate LIKE '%JAN%';

--.List customer names of all who have purchased products with a cost less than Rs.1600.
SELECT P.custno FROM PURCHASE P INNER JOIN PRODUCT PRO ON P.PRONO=PRO.product_no WHERE PRO.price<1600;

--.Get customr number of purchases such that the quantity is more than the maximum quantity of all purchases of C00002.
SELECT custno FROM PURCHASE WHERE quantity>(SELECT MAX(quantity) FROM PURCHASE WHERE custno='C00002'); 

--Get the name o all customer who have not purchased any item currently. 
SELECT C.NAME FROM CUSTOMER C INNER JOIN PURCHASE P ON C.cust_no=P.custno WHERE C.cust_no NOT IN (SELECT custno FROM PURCHASE);

----correlated queries----------
--.List all customer number pairs such that cost of the item purchased by the first customer is less than that of second customer. 
SELECT DISTINCT P1.custno AS CUSTOMER1,P2.custno AS CUSTOMER2 FROM PURCHASE P1,PURCHASE P2 WHERE (SELECT PRICE FROM PRODUCT WHERE product_no=P2.PRONO)>(SELECT PRICE FROM PRODUCT WHERE product_no=P1.PRONO) AND P1.CUST_NO <> P2.CUST_NO;

--. List pairs of customer-names of all who has purchased products with cost less than Rs 1600 .
SELECT DISTINCT C1.NAME AS CUST, C2.NAME AS CUST_2
FROM CUSTOMER C1
JOIN PURCHASE P1 ON C1.CUST_NO = P1.CUST_NO
JOIN PRODUCT R1 ON P1.PROD_NO = R1.PRODUCT_NO
JOIN CUSTOMER C2
JOIN PURCHASE P2 ON C2.CUST_NO = P2.CUST_NO
JOIN PRODUCT R2 ON P2.PROD_NO = R2.PRODUCT_NO
WHERE R1.PRICE < 1600 
  AND R2.PRICE < 1600 
  AND C1.CUST_NO <> C2.CUST_NO;

--Get product numbers of all products purchased by more than one customer 
SELECT DISTINCT P1.PROD_NO
FROM PURCHASE P1
JOIN PURCHASE P2 ON P1.PROD_NO = P2.PROD_NO AND P1.CUST_NO <> P2.CUST_NO;

-- Get the names of customers who have purchased the item P00002 
select DISTINCT c.name from customer c join purchase p on c.cust_no=p.custno where p.prono='P00002';

-- Get the names of customers who have not purchased the item P00002 
select DISTINCT c.name from customer c LEFT join purchase p on c.cust_no=p.custno AND p.prono!='P00002' AND P.PRONO IS NULL;

-- Get the names of customer who have purchased at least all those products purchased by C00004
SELECT C.NAME FROM CUSTOMER C INNER JOIN PURCHASE P ON C.CUST_NO=P.custno INNER JOIN PURCHASE P2 ON P2.CUSTNO=P.CUSTNO WHERE P2.CUSTNO='P00004' AND C.CUST_NO <> 'P00004'; 