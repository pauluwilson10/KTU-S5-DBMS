file_path = ' t'
data = []

# Read the CSV file and store transactions in 'data'
with open(file_path, 'r') as file:
    next(file)  # Skip header if present
    for line in file:
        temp = line.strip().split(',')
        data.append(temp)

# Initialize a dictionary to store item frequencies
frequent_itemset = {}

# First pass: Count single item frequencies
for transaction in data:
    for item in transaction:
        item = tuple([item])  # Convert single item to a tuple
        if item in frequent_itemset:
            frequent_itemset[item] += 1
        else:
            frequent_itemset[item] = 1

# Second pass: Count pair item frequencies
for transaction in data:
    for i in range(len(transaction)):
        for j in range(i+1, len(transaction)):
            item = tuple(sorted([transaction[i], transaction[j]]))  # Ensure the pair is sorted
            if item in frequent_itemset:
                frequent_itemset[item] += 1
            else:
                frequent_itemset[item] = 1

# Third pass: Count triplet item frequencies
for transaction in data:
    for i in range(len(transaction)):
        for j in range(i+1, len(transaction)):
            for k in range(j+1, len(transaction)):
                item = tuple(sorted([transaction[i], transaction[j], transaction[k]]))  # Ensure the triplet is sorted
                if item in frequent_itemset:
                    frequent_itemset[item] += 1
                else:
                    frequent_itemset[item] = 1

# Filter out itemsets with support less than the minimum support (2 in this case)
min_support = 2
frequent_itemset = {item: count for item, count in frequent_itemset.items() if count >= min_support}

# Generate association rules
min_confidence = 0.34
rules = []

for item in frequent_itemset.keys():
    if len(item) < 2:  # Skip itemsets with fewer than 2 items
        continue
    for i in range(1, len(item)):
        antecedent = item[:i]
        consequent = item[i:]
        antecedent_support = frequent_itemset.get(antecedent, 0)
        if antecedent_support > 0:
            confidence = frequent_itemset[item] / antecedent_support
            if confidence > min_confidence:
                rules.append((antecedent, consequent, confidence))

# Print the association rules
print("\nAssociation Rules:")
for rule in rules:
    print(f"{rule[0]} --> {rule[1]} | Confidence: {rule[2]}")
