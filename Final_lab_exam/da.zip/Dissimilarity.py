import pandas as pd
import numpy as np

file_path = 'dissimilarity.csv'

def read(file_path):
    data = pd.read_csv(file_path)
    print(data)
    return data

def euclidean_distance(point1, point2):
    return np.sqrt(np.sum((point2 - point1) ** 2))

def hamming_distance(row1, row2):
    return np.sum(row1 != row2)  # Counts mismatches element-wise

def calculate_dissimilarity(data):
    # Separate columns by type
    numerical_columns = data.select_dtypes(include=['number']).columns
    nominal_columns = data.select_dtypes(include=['object']).columns

    # Extract numerical and nominal data
    numerical_data = data[numerical_columns].values
    nominal_data = data[nominal_columns].values
    length = len(data)

    # Initialize dissimilarity matrices
    numerical_dissimilarity = np.zeros((length, length))
    nominal_dissimilarity = np.zeros((length, length))
    mixed_dissimilarity = np.zeros((length, length))

    # Calculate distances
    for i in range(length):
        for j in range(i + 1, length):
            # Numerical dissimilarity (Euclidean)
            num_dist = euclidean_distance(numerical_data[i], numerical_data[j])
            numerical_dissimilarity[i][j] = num_dist
            numerical_dissimilarity[j][i] = num_dist  # Symmetric matrix

            # Nominal dissimilarity (Hamming)
            nom_dist = hamming_distance(nominal_data[i], nominal_data[j])
            nominal_dissimilarity[i][j] = nom_dist
            nominal_dissimilarity[j][i] = nom_dist  # Symmetric matrix

            # Mixed dissimilarity (sum of numerical and nominal distances)
            mixed_dist = num_dist + nom_dist
            mixed_dissimilarity[i][j] = mixed_dist
            mixed_dissimilarity[j][i] = mixed_dist  # Symmetric matrix

    return numerical_dissimilarity, nominal_dissimilarity, mixed_dissimilarity

# Load data and calculate dissimilarity matrices
data = read(file_path)
numerical_matrix, nominal_matrix, mixed_matrix = calculate_dissimilarity(data)

# Display each matrix
print("\nNumerical Dissimilarity Matrix:")
print(numerical_matrix)

print("\nNominal Dissimilarity Matrix:")
print(nominal_matrix)

print("\nMixed Dissimilarity Matrix:")
print(mixed_matrix)
