import random
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def euclidean_distance(point1, point2):
    return np.sqrt(np.sum((point2 - point1) ** 2))


def update_centroid(clusters):
    new_centroid = []
    for cluster in clusters.values():
        if cluster:
            x = np.sum([point[0] for point in cluster]) / len(cluster)
            y = np.sum([point[1] for point in cluster]) / len(cluster)
            new_centroid.append((x, y))
    return new_centroid


def k_means(data, k):
    data = data.tolist()
    centroids = random.sample(data, k)
    previous_centroids = []
    clusters = {i: [] for i in range(k)}

    iteration = 0  # Track iteration number
    while centroids != previous_centroids:
        previous_centroids = centroids.copy()
        for i in range(k):
            clusters[i] = []

        for point in data:
            distances = [euclidean_distance(point, np.array(centroid)) for centroid in centroids]
            min_index = distances.index(min(distances))
            clusters[min_index].append(point)

        # Print clusters for this iteration
        print(f"Iteration {iteration + 1}:")
        for i, cluster in clusters.items():
            print(f"  Cluster {i + 1}: {cluster}")

        centroids = update_centroid(clusters)
        iteration += 1

    return clusters, centroids


file_path = 'k_means.csv'
data = pd.read_csv(file_path).values
k = int(input("Enter number of clusters: "))
clusters, centroids = k_means(data, k)

# Plotting
for i in range(k):
    x, y = zip(*clusters[i])
    plt.scatter(x, y, label=f'Cluster {i + 1}')

centroid_x, centroid_y = zip(*centroids)
plt.scatter(centroid_x, centroid_y, marker='*', color="red", label='Centroids')
plt.title("K-Means Clustering")
plt.xlabel("X-Axis")
plt.ylabel("Y-Axis")
plt.legend()
plt.show()
