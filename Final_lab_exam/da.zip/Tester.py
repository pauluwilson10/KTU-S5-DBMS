import pandas as pd

file_path = 'test.csv'
data=pd.read_csv(file_path)

print(data)