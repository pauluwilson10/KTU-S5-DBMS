import numpy as np
import pandas as pd
file_path='covariance.csv'
data=pd.read_csv(file_path)
x=data['X'].values
y=data['Y'].values
length=len(x)
x_mean=np.mean(x)
y_mean=np.mean(y)
covar_iance=np.sum((x-x_mean)*(y-y_mean))/length
print('Covariance :',covar_iance)
x_std=np.std(x)
y_std=np.std(y)
correlation_coefficient=covar_iance/(x_std*y_std)
print('Correlation Coefficient: ',correlation_coefficient)
if correlation_coefficient<0:
    print('negative relation')
elif correlation_coefficient==0:
    print('no relation')
else:
    print('Positive relation')

