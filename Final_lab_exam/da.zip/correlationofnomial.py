import pandas as pd
from scipy.stats import chi2_contingency
data=pd.read_csv('correlationofnominal.csv')
contigency_table=pd.crosstab(data['Attribute1'],data['Attribute2'])
chi2,p_value,dof,expected=chi2_contingency(contigency_table)
print(f"Contingency Table:\n{contigency_table}\n")
print(f"Chi-Square Statistic: {chi2}")
print(f"Degrees of Freedom: {dof}")
print(f"Expected Frequencies:\n{expected}")
print(f"P-Value: {p_value}")
alpha=0.05
if p_value < alpha:
    print("Reject the null hypothesis: There is a significant correlation between the attributes.")
else:
    print("Fail to reject the null hypothesis: There is no significant correlation between the attributes.")
