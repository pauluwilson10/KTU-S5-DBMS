import math


# Function to read data from the file
def read_data(file_path):
    data = []
    with open(file_path, 'r') as file:
        next(file)  # Skip header
        for line in file:
            value = line.strip().split(',')
            features = value[:-1]
            label = value[-1]
            data.append((features, label))
    return data


# Function to calculate entropy
def entropy(data):
    label_count = {}
    for _, label in data:
        if label not in label_count:
            label_count[label] = 0
        label_count[label] += 1

    ent = 0
    for label in label_count:
        prob = label_count[label] / len(data)
        ent -= prob * math.log2(prob)
    return ent


# Function to split data based on a feature and its value
def split_tree(data, index, value):
    true_branch = [row for row in data if row[0][index] == value]
    false_branch = [row for row in data if row[0][index] != value]
    return true_branch, false_branch


# Function to find the best split
def best_split(data):
    best_gain = 0
    best_index = None
    best_value = None
    total_length = len(data[0][0])
    current_entropy = entropy(data)

    for index in range(total_length):
        values = set(row[0][index] for row in data)
        for value in values:
            true_branch, false_branch = split_tree(data, index, value)
            if not true_branch or not false_branch:
                continue

            p = len(true_branch) / len(data)
            gain = current_entropy - (p * entropy(true_branch)) - ((1 - p) * entropy(false_branch))
            if gain > best_gain:
                best_gain, best_index, best_value = gain, index, value
    return best_gain, best_index, best_value


# Function to build the decision tree
def build_tree(data):
    gain, index, value = best_split(data)
    if gain == 0:
        return {'prediction': data[0][1]}

    true_branch, false_branch = split_tree(data, index, value)
    return {
        'index': index,
        'value': value,
        'true_branch': build_tree(true_branch),
        'false_branch': build_tree(false_branch)
    }


# Function to classify a new sample using the decision tree
def classify(tree, sample):
    if 'prediction' in tree:
        return tree['prediction']
    elif sample[tree['index']] == tree['value']:
        return classify(tree['true_branch'], sample)
    else:
        return classify(tree['false_branch'], sample)

# Function to print the decision tree
def print_tree(tree, spacing=""):
    # Base case: if the tree is a leaf node, print the prediction
    if "prediction" in tree:
        print(spacing + "Predict:", tree["prediction"])
        return

    # Print the question at this node
    print(f'{spacing}[Feature {tree["index"]}] == {tree["value"]}?')

    # Recursively call this function on the true branch
    print(spacing + '--> True:')
    print_tree(tree["true_branch"], spacing + "    ")

    # Recursively call this function on the false branch
    print(spacing + '--> False:')
    print_tree(tree["false_branch"], spacing + "    ")

# Display the tree structure


# Load the data
file_path = 'decision.csv'
data = read_data(file_path)
tree = build_tree(data)
print_tree(tree)
# User input for a new sample
age = input("Enter age (youth, middle_aged, senior): ")
income = input("Enter income (low, medium, high): ")
student = input("Enter student (yes, no): ")
credit_rating = input("Enter credit rating (fair, good, excellent): ")
new_sample = [age, income, student, credit_rating]

# Predict class
predicted_class = classify(tree, new_sample)
print(f'\nPredicted class for {new_sample}: {predicted_class}')
