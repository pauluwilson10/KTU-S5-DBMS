#program to enter values and obtain mean median and mode
import numpy as np
numbers=[]
i=int(input("Enter number of elements\n"))
print("Enter numbers",end="")
print(':')
for j in range(0,i):
    num = int(input(f"Enter {j + 1} th element: "))
    numbers.append(num)
mean=np.mean(numbers)
median=np.median(numbers)
mode={}
for i in numbers:
    if i not in  mode.keys():
        mode[i]=1
    else:
        mode[i]+=1
max_frequency=max(mode.values())
max_values=[key for key,values in mode.items() if values== max_frequency]
print(len(max_values))

print(f"Median: {median}            Mean:{mean}           mode:{max_values}")
if len(max_values) == 1:
    print("Unimodal")
elif len(max_values) == 2:
    print("Bimodal")
elif len(max_values) == 3:
    print("Trimodal")
else:
    print("Multimodal")
