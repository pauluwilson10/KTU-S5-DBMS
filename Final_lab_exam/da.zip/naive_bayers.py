def read(file_path):
    data = []
    with open(file_path, 'r') as file:
        next(file)
        for line in file:
            line = line.strip().split(',')
            feature = line[:-1]
            label = line[-1]
            data.append((feature, label))
    return data

def class_count(data):
    c_count = {}
    for _, label in data:
        if label not in c_count:
            c_count[label] = 0
        c_count[label] += 1
    return c_count

def feature_count(data):
    f_count = {}
    for feature, label in data:
        if label not in f_count:
            f_count[label] = [{} for _ in range(len(feature))]
        for i in range(len(feature)):
            value = feature[i]
            if value not in f_count[label][i]:
                f_count[label][i][value] = 0
            f_count[label][i][value] += 1
    return f_count

def probabilities(data, new_sample):
    probability = {}
    c_count = class_count(data)
    f_count = feature_count(data)
    total_samples = len(data)

    for label in c_count:
        prob = c_count[label] / total_samples
        for i in range(len(new_sample)):
            feature = new_sample[i]
            feat_count = f_count[label][i].get(feature, 0)
            temp = (feat_count + 1) / (c_count[label] + 2)
            prob *= temp
        probability[label] = prob
    return probability

new_sample = ['youth', 'high', 'yes', 'excellent']
file_path = 'naive_bayes.csv'
data = read(file_path)
probs = probabilities(data, new_sample)

for label, prob in probs.items():
    print(f'{label}: {prob}')

max_label = max(probs, key=probs.get)
print('Max probability is:', max_label)
