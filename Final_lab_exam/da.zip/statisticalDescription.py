#program to obtain q0,q1,q2,q3,q4,outliers and remove from a given csv file
import numpy as np
def read(file_path):
    with open(file_path,'r') as file:
        data=[]
        next(file)
        for line in file:
            line=line.strip().split(',')
            data.append(int(line[1]))
    return data
file_path='statisticalDescription.csv'
data=read(file_path)
q0=np.min(data)
q1=np.percentile(data,25)
q2=np.median(data)
q3=np.percentile(data,75)
q4=np.max(data)

print(f"Q0 (Min): {q0}")
print(f"Q1 (25th Percentile): {q1}")
print(f"Q2 (Median): {q2}")
print(f"Q3 (75th Percentile): {q3}")
print(f"Q4 (Max): {q4}")

IQR=q3-q1
print(f"IQR: {IQR}")

lower_bound=q1-1.5*IQR
upper_bound=q3+1.5*IQR
outlier=[value for value in data if value<lower_bound or value>upper_bound]
print(f"Outliers: {outlier}")

cleaned_data=[value for value in data if lower_bound < value < upper_bound]
print(f"Cleaned Data (without outliers): {cleaned_data}")


